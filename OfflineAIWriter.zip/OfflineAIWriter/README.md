# Offline AI Writer — build & install

Engine: Google MediaPipe LLM Inference (on-device). Model: Qwen2.5-0.5B-Instruct (.task). No login, no ads, no API keys.

## Build
1. Install Android Studio (Koala or newer). Open the `OfflineAIWriter` folder. Let Gradle sync (needs internet once).
2. Create a signing key (once):
   keytool -genkeypair -v -keystore release.keystore -alias writer -keyalg RSA -keysize 2048 -validity 10000
   Put release.keystore in the project root folder.
3. Copy keystore.properties.example to keystore.properties and fill in your passwords.
4. Build the signed APK:
   Terminal in Android Studio:  gradlew assembleRelease     (Windows)   ./gradlew assembleRelease   (Mac/Linux)
   Or menu: Build > Generate Signed App Bundle / APK > APK.
   Output: app/build/outputs/apk/release/app-release.apk

## Install
Copy the APK to your phone, open it, allow "Install unknown apps". Or: adb install app-release.apk

## First run
Open the app > "Download model (WiFi)" (about 550 MB, once). Afterwards turn on airplane mode: it still works.
If download fails, download the .task file on any device and use "Import model file".

## Notes
- Needs a 64-bit ARM Android phone (arm64), Android 8+, about 3 GB+ free RAM.
- Hindi quality of a 0.5B model is limited; for better quality use a larger MediaPipe .task model (e.g. Gemma 3 1B after accepting its license on Hugging Face) via "Import model file". The prompt template in MainActivity.kt (buildPrompt) is for Qwen; Gemma uses <start_of_turn>user ... <end_of_turn><start_of_turn>model.
