package com.offlinewriter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// Small open model (Qwen2.5 0.5B, MediaPipe .task format). If this link ever changes, use "Import model file".
const val MODEL_URL = "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"

enum class Mode(val label: String, val task: String) {
    WRITE("AI Writing", "Write on the given topic, or continue the given text."),
    GRAMMAR("Grammar", "Correct the grammar, spelling and punctuation of the text. Return only the corrected text."),
    REWRITE("Rewrite", "Rewrite the text more clearly and professionally, keeping the meaning."),
    SHORT("Short answer", "Answer in one to three sentences."),
    LONG("Long answer", "Answer in detail using several paragraphs."),
    ESSAY("Essay", "Write a well-structured essay with introduction, body and conclusion on the topic."),
    LETTER("Letter", "Write a properly formatted letter as requested."),
    STORY("Story", "Write a creative short story based on the idea."),
    SUMMARY("Summarize", "Summarize the text briefly in a few lines.")
}

fun buildPrompt(m: Mode, lang: String, text: String): String {
    val l = when (lang) {
        "Hindi" -> "Reply only in Hindi (Devanagari script)."
        "English" -> "Reply only in English."
        else -> "Reply in the same language as the user's text."
    }
    val sys = "You are an offline writing assistant. ${m.task} $l Output only the result."
    return "<|im_start|>system\n$sys<|im_end|>\n<|im_start|>user\n$text<|im_end|>\n<|im_start|>assistant\n"
}

class Engine(private val ctx: Context) {
    var llm: LlmInference? = null
    var onPartial: ((String, Boolean) -> Unit)? = null
    val file get() = File(ctx.filesDir, "model.task")
    fun ready() = file.exists() && file.length() > 1_000_000
    fun load() {
        val o = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(file.absolutePath)
            .setMaxTokens(1024)
            .setResultListener { p, d -> onPartial?.invoke(p, d) }
            .build()
        llm = LlmInference.createFromOptions(ctx, o)
    }
}

data class Entry(val mode: String, val q: String, val a: String, val ts: Long)
data class Msg(val role: String, val text: String)

class Store(c: Context) {
    private val f = File(c.filesDir, "history.json")
    fun all(): List<Entry> = try {
        val arr = JSONArray(f.readText())
        List(arr.length()) { val o = arr.getJSONObject(it); Entry(o.getString("m"), o.getString("q"), o.getString("a"), o.getLong("t")) }
    } catch (e: Exception) { emptyList() }
    fun write(l: List<Entry>) {
        f.writeText(JSONArray(l.map { JSONObject().put("m", it.mode).put("q", it.q).put("a", it.a).put("t", it.ts) }).toString())
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val engine = remember { Engine(ctx) }
    val store = remember { Store(ctx) }
    val msgs = remember { mutableStateListOf<Msg>() }
    val listState = rememberLazyListState()
    var state by remember { mutableStateOf(if (engine.ready()) "loading" else "nomodel") }
    var progress by remember { mutableStateOf(0f) }
    var info by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(Mode.WRITE) }
    var lang by remember { mutableStateOf("Auto") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showHist by remember { mutableStateOf(false) }
    var hist by remember { mutableStateOf(store.all()) }

    fun loadModel() {
        scope.launch { 
            state = "loading"
            try { withContext(Dispatchers.IO) { engine.load() }; state = "idle" }
            catch (e: Throwable) { info = "Could not load model: ${e.message}"; state = "nomodel" }
        }
    }
    LaunchedEffect(Unit) { if (engine.ready()) loadModel() }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            state = "downloading"; progress = -1f
            try {
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openInputStream(uri)!!.use { i -> engine.file.outputStream().use { o -> i.copyTo(o) } }
                }
                loadModel()
            } catch (e: Throwable) { info = "Import failed: ${e.message}"; state = "nomodel" }
        }
    }

    fun download() {
        scope.launch {
            state = "downloading"; progress = 0f; info = ""
            try {
                withContext(Dispatchers.IO) {
                    val c = URL(MODEL_URL).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000; c.readTimeout = 30000
                    val total = c.contentLengthLong
                    val tmp = File(ctx.filesDir, "model.part")
                    c.inputStream.use { i -> tmp.outputStream().use { o ->
                        val b = ByteArray(65536); var n = 0L
                        while (true) { val r = i.read(b); if (r < 0) break; o.write(b, 0, r); n += r; if (total > 0) progress = n.toFloat() / total }
                    } }
                    tmp.renameTo(engine.file)
                }
                loadModel()
            } catch (e: Throwable) { info = "Download failed: ${e.message}. Check internet, or use Import."; state = "nomodel" }
        }
    }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        input = ""; busy = true
        msgs.add(Msg("me", t)); msgs.add(Msg("ai", "…"))
        val idx = msgs.lastIndex
        var acc = ""
        engine.onPartial = { p, d ->
            acc += p
            if (idx < msgs.size) msgs[idx] = Msg("ai", acc)
            if (d) busy = false
        }
        try { engine.llm!!.generateResponseAsync(buildPrompt(mode, lang, t)) }
        catch (e: Throwable) { msgs[idx] = Msg("ai", "Error: ${e.message}"); busy = false }
    }

    BackHandler(showHist) { showHist = false }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Offline AI Writer") }, actions = {
            TextButton(onClick = { hist = store.all(); showHist = !showHist }) { Text(if (showHist) "Back" else "History") }
            TextButton(enabled = !busy, onClick = { msgs.clear() }) { Text("Clear") }
        })
    }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp).fillMaxSize().imePadding()) {
            when {
                state != "idle" -> Column(Modifier.fillMaxWidth().padding(top = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    when (state) {
                        "nomodel" -> {
                            Text("One-time setup: the AI model (about 550 MB) must be on your phone. After that, everything works offline.")
                            Button(onClick = { download() }, Modifier.fillMaxWidth()) { Text("Download model (WiFi)") }
                            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Import model file (.task)") }
                        }
                        "downloading" -> {
                            Text("Getting model…")
                            if (progress >= 0f) LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth())
                            else LinearProgressIndicator(Modifier.fillMaxWidth())
                        }
                        else -> { Text("Loading model into memory…"); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                    }
                    if (info.isNotEmpty()) Text(info, color = MaterialTheme.colorScheme.error)
                }
                showHist -> LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hist.isEmpty()) item { Text("No saved writing yet.", Modifier.padding(top = 16.dp)) }
                    items(hist) { e ->
                        Card(Modifier.fillMaxWidth(), onClick = {
                            msgs.clear(); msgs.add(Msg("me", e.q)); msgs.add(Msg("ai", e.a)); showHist = false
                        }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(e.mode, style = MaterialTheme.typography.labelMedium)
                                Text(e.q, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                                TextButton(onClick = {
                                    val n = store.all().filter { it.ts != e.ts }; store.write(n); hist = n
                                }) { Text("Delete") }
                            }
                        }
                    }
                }
                else -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(Mode.values().toList()) { m -> FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label) }) }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("Auto", "English", "Hindi")) { l -> FilterChip(selected = lang == l, onClick = { lang = l }, label = { Text(l) }) }
                    }
                    LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (msgs.isEmpty()) item { Text("Type a topic or paste text below, pick a mode, and tap Send.", Modifier.padding(top = 16.dp)) }
                        items(msgs.size) { i ->
                            val m = msgs[i]
                            val me = m.role == "me"
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (me) Alignment.End else Alignment.Start) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (me) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (me) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                ) { Text(m.text, Modifier.padding(12.dp)) }
                                if (!me && !(busy && i == msgs.lastIndex)) Row {
                                    TextButton(onClick = { clip.setText(AnnotatedString(m.text)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }) { Text("Copy") }
                                    TextButton(onClick = {
                                        val s = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m.text)
                                        ctx.startActivity(Intent.createChooser(s, "Share"))
                                    }) { Text("Share") }
                                    TextButton(onClick = {
                                        val q = if (i > 0) msgs[i - 1].text else ""
                                        val n = listOf(Entry(mode.label, q, m.text, System.currentTimeMillis())) + store.all()
                                        store.write(n); hist = n
                                        Toast.makeText(ctx, "Saved on this phone", Toast.LENGTH_SHORT).show()
                                    }) { Text("Save") }
                                }
                            }
                        }
                    }
                    Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Write anything…") }, maxLines = 5)
                        Button(onClick = { send() }, enabled = !busy && input.isNotBlank()) { Text(if (busy) "…" else "Send") }
                    }
                }
            }
        }
    }
}
